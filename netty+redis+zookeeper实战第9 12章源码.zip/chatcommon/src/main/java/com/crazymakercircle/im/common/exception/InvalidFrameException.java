package com.crazymakercircle.im.common.exception;

/**
 * create by 尼恩 @ 疯狂创客圈
 **/
public class InvalidFrameException extends Exception {

    public InvalidFrameException(String s) {
        super(s);
    }
}
